<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<!-- Website Title & Description for Search Engine purposes -->
		<title>Cassiano Doneda</title>
		<meta name="description" content="">
		
		<!-- Mobile viewport optimized -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		
		<!-- Bootstrap CSS -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="includes/css/bootstrap-glyphicons.css" rel="stylesheet">
		
		<!-- Custom CSS -->
		<link href="includes/css/styles.css" rel="stylesheet">
		
		<!-- Include Modernizr in the head, before any other Javascript -->
		<script src="includes/js/modernizr-2.6.2.min.js"></script>
		
	</head>
	<body>

		<div class="container" id="main">
			<div class="navbar navbar-fixed-top">
				<div class="container">

					<button class="navbar-toggle" data-target=".navbar-responsive-collapse" data-toggle="collapse" type="button">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

					<a class="navbar-brand" href="/"><img src="images/logo.png" alt="seu logo"></a>
					<div class="nav-collapse collapse navbar-responsive-collapse">
						<ul class="nav navbar-nav">
							<li class="active">
								<a href="#">Cadastre-se</a>
							</li>

							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Sobre o Good Friends <strong class="caret"></strong></a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">Como funciona?</a>
									</li>
									<li>
										<a href="#">O que preciso fazer?</a>
									</li>

									<li class="divider"></li>

									<li class="dropdown-header">
										Sobre nós
									</li>
									<li>
										<a href="#">Equipe</a>
									</li>
									<li>
										<a href="#">Projetos</a>
									</li>

								</ul>
							</li>
						</ul>
					<!--	<form class="navbar-form pull-left">
							<input type="text" class="form-control" id="searchInput" placeholder="Pesquise aqui!">
							<button type="submit" class="btn-primary"><span class="glyphicon glyphicon-search"></span></button>
						</form> -->
						<ul class="nav navbar-nav pull-right">
							<li class="active">
								<a href="#"><span class="glyphicon glyphicon-thumbs-up"></span>  Login</a>
							</li>

						</ul>

					</div>

				</div>
			</div>


			<div class="carousel slide" id="myCarousel">

				<!-- indicadores -->
				<ol class="carousel-indicators">
					<li class="active" data-slide-to="0" data-target="#myCarousel"></li>
					<li data-slide-to="1" data-target="#myCarousel"></li>
					<li data-slide-to="2" data-target="#myCarousel"></li>


				</ol>

				<!-- wrapper para os slides -->
				<div class="carousel-inner">
					<div class="item active" id="slide1">
						<div class="carousel-caption">
							<h4>Bem vindo ao Good Friends!</h4>
							<p>Você vem triste, nós te apresentamos amigos!</p>
						</div>


					</div>
					<div class="item" id="slide2">
						<div class="carousel-caption">
							<h4>Seus amigos não podem/querem falar agora?</h4>
							<p>Encontre um Good Friend online para falar sobre o que você quiser imediatamente! É só apertar um botão!</p>
						</div>


					</div>
					<div class="item" id="slide3">
						<div class="carousel-caption">
							<h4>Seu problema não é urgente?</h4>
							<p>Crie um tópico sobre o assunto e aguarde a resposta dos demais Good Friends! O melhor ambiente para sentir-se revigorado é aqui!</p>
						</div>


					</div>

				</div>

				<!-- controles do carrossel -->
				<a class="left carousel-control" data-slide="prev" href="#myCarousel"><span class="icon-prev"></span></a>
				<a class="right carousel-control" data-slide="next" href="#myCarousel"><span class="icon-next"></span></a>
			</div>


			<div class="row" id="bigCallout">
				<div class="col-12">

					<div class="alert alert-success alert-block fade in" id="successAlert">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
						<h4>No Good Friends você pode:</h4>
						<p>Encontrar amigos verdadeiros! E que se preocupam em lhe ajudar (e com sua nota ao final da conversa) <span class="glyphicon glyphicon-certificate"></span> </p>
					</div>

					<div class="well well-small visible-sm">
						<a href="#" class="btn btn-large btn-block btn-default"><span class="glyphicon glyphicon-thumbs-up"></span>Curta nossa FanPage!</a>
					</div>

					<div class="well">
						<div class="page-header">
							<h1>Conheça um Good Friend! <small> Você não vai se arrepender!</small></h1>
						</div>
						<p class="lead">Em um mundo onde as amizades estão cada vez menos verdadeiras, o Good Friends oferece um mundo onde ser amigo é sua melhor opção! Quanto mais conversas boas você tiver, maior é sua reputação!</p>
						<a href="#" class="btn btn-large btn-primary" id="alertaAqui">Conheça mais!</a>
						<!--<a href="#" class="btn btn-large btn-link">Ou aperta aqui!</a>-->
					</div>

				</div>

			</div>

			<div class="row" id="featuresHeading">
				<div class="col-12">
					<h2>Características</h2>
					<p class="lead">O sistema foi projetado para que você nunca fique sem ajuda! Você aparece com um problema e encontra uma pessoa que passou pela mesma situação para lhe ajudar! <br> Você pode escolher entre anonimato (somente sua idade e um nome fictício ficam visíveis) ou entre tornar-se conhecido (somente os dados que você escolher ficam visíveis).</p>
				</div>
			</div>


			<div class="row" id="features">
                <div class="col-sm-4 feature">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Formas de utilização</h3>
                        </div>
                        <img src="http://placehold.it/200" class="img-circle">

                        <p><strong>Formato Tempo Real</strong> - A ajuda vem até você com o clicar de um botão! <br><br> <strong>Formato Painel 24h</strong> - Você pede ajuda e sua pergunta fica disponível por 24h para quem quiser comentar e lhe ajudar!</p>
                        <a href="#" target="_blank" class="btn btn-warning btn-block">Nada aqui!</a>
                    </div>
                </div>

                <div class="col-sm-4 feature">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Características Principais</h3>
                        </div>
                        <img src="http://placehold.it/200" class="img-circle">

                        <p><ul class="unstyled">
                            <li><strong>Sigilo completo!</strong> - Sua identidade só fica disponivel se você quiser!</li>
                            <li><strong>Avaliação</strong> após o chat - Cada pessoa pode avaliar o Good Friend após o fim da conversa!</li>
                            <li><strong>24 horas disponível</strong> - O sistema está disponível 24h por dia! Só depende da quantidade de pessoas que você encontrar online!</li>
                    </ul></p>
                        <a href="#" target="_blank" class="btn btn-default btn-block">Nada aqui!</a>
                    </div>
                </div>

                <div class="col-sm-4 feature">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Funções Incríveis!</h3>
                        </div>
                        <img src="http://placehold.it/200" class="img-circle">

                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis sint sit voluptates. Accusamus ex illum libero minus quae quo tenetur! </p>
                        <a href="#" target="_blank" class="btn btn-info btn-block">Nada aqui!</a>
                    </div>
                </div>
			</div>


			<div class="row" id="moreInfo">
                <div class="col-sm-6">
                    <h3>Alguns extras</h3>
                    <div class="tabbable">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab1" data-toggle="tab">Primeiro aqui</a></li>
                            <li ><a href="#tab2" data-toggle="tab">Depois aqui</a></li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="tab1">
                                <h4><span class="glyphicon glyphicon-map-marker"></span> Our Location <small>More like our favourite surf spot</small></h4>

                                <iframe width="100%" height="200" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.ca/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=waikiki+beach&amp;aq=&amp;sll=19.896766,-155.582782&amp;sspn=8.711424,11.854248&amp;ie=UTF8&amp;hq=&amp;hnear=Waikiki+Beach,+Honolulu,+Hawaii,+United+States&amp;t=m&amp;ll=21.277298,-157.8265&amp;spn=0.015996,0.036478&amp;z=14&amp;output=embed"></iframe>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            </div>
                            <div class="tab-pane" id="tab2">
                                <h4>Outra info qualquer <small>Não se preocupa que logo tem conteúdo!</small></h4>
                                
                                <img src="http://placehold.it/200" class="thumbnail pull-left">

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis dolore ducimus exercitationem iste necessitatibus, nemo omnis optio repellat! Beatae exercitationem explicabo fuga impedit nobis. Corporis libero nihil nostrum perferendis Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis explicabo iste quam tempore. Accusantium ad consequatur, debitis doloribus eligendi eos fuga id, inventore magni optio praesentium quaerat quod recusandae repellat?</p>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis dolore ducimus exercitationem iste necessitatibus, nemo omnis optio repellat! Beatae exercitationem explicabo fuga impedit nobis. Corporis libero nihil nostrum perferendis Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis explicabo iste quam tempore. Accusantium ad consequatur, debitis doloribus eligendi eos fuga id, inventore magni optio praesentium quaerat quod recusandae repellat?</p>

                                <a href="#myModal" role="button" class="btn btn-default" data-toggle="modal">Clique para se cadastrar!</a>
                                <div class="modal fade" id="myModal">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button class="close" data-dismiss="modal">&times;</button>

                                                <h4 class="modal-title">Cadastre-se</h4>
                                            </div>
                                            <div class="modal-body">
                                                <h4>Texto</h4>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur doloremque dolores eaque laudantium natus, nemo numquam odio perferendis porro praesentium quam quibusdam quidem repellendus reprehenderit sapiente, vel, veritatis.</p>

                                                <h4>Popover na modal</h4>
                                                <a href="#" class="btn btn-danger pop" data-toggle="popover" data-placement="top" data-original-title="Ae Clicou!" data-content="Você clicou mesmo!">Clica ai!</a>

                                                <h4>Dicas de ferramentas</h4>
                                                <a href="" data-original-title="Dica!" rel="tooltip">Esse link</a> deve ter uma tooltip e <a href="" data-original-title="Dica2" rel="tooltip">esse outro</a> também!
                                                <hr>

                                                <p><small class="text-muted">O formulario não faz nada ainda</small></p>

                                                <form class="form-horizontal">
                                                    <div class="form-group">
                                                        <label class="col-lg-2 control-label" for="inputName">Name</label>
                                                        <div class="col-lg-10">
                                                            <input type="text" class="form-control" id="inputName" placeholder="Nome">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-lg-2 control-label" for="inputEmail">Email</label>
                                                        <div class="col-lg-10">
                                                            <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-lg-2 control-label" for="inputMsg">Mensagem</label>
                                                        <div class="col-lg-10">
                                                            <textarea class="form-control" id="inputMsg" placeholder="Mensagem" rows="3"></textarea>
                                                            <button class="btn btn-success pull-right" type="submit">Enviar</button>
                                                        </div>
                                                    </div>
                                                </form>


                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-default" data-dismiss="modal" type="button">Fechar</button> <button class="btn btn-primary" type="button">Salvar Alterações</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <h3>Alguma informação</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores eligendi labore pariatur quisquam rem reprehenderit saepe ullam voluptates. Alias aut distinctio eius illum modi nesciunt odio quae quibusdam. Similique, soluta!</p>

                    <h4>Grupo de listas</h4>
                    <div class="list-group">
                        <a href="" class="list-group-item">
                            <h4 class="list-group-item-heading">Olá!</h4>
                            <p class="list-group-item-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium cum deserunt in laborum odit! Alias dolore doloremque ipsa ipsum nobis quas sit tempore! Ab ex fuga ipsum nostrum quae veniam?</p>
                        </a>
                        <a href="" class="list-group-item">
                            <h4 class="list-group-item-heading">Hey!</h4>
                            <p class="list-group-item-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium cum deserunt in laborum odit! Alias dolore doloremque ipsa ipsum nobis quas sit tempore! Ab ex fuga ipsum nostrum quae veniam?</p>
                        </a>
                        <a href="" class="list-group-item">
                            <h4 class="list-group-item-heading">Psiu!</h4>
                            <p class="list-group-item-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium cum deserunt in laborum odit! Alias dolore doloremque ipsa ipsum nobis quas sit tempore! Ab ex fuga ipsum nostrum quae veniam?</p>
                        </a>
                        <a href="" class="list-group-item">
                            <h4 class="list-group-item-heading">Wazzaaaaap</h4>
                            <p class="list-group-item-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium cum deserunt in laborum odit! Alias dolore doloremque ipsa ipsum nobis quas sit tempore! Ab ex fuga ipsum nostrum quae veniam?</p>
                        </a>
                    </div>
                    <h5>Um titulo pequeno</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci alias asperiores commodi consequatur delectus doloribus ea explicabo, iure iusto minima, modi natus neque obcaecati odit, officiis porro quos sapiente vitae!</p>
                </div>
			</div>

            <hr>

			<div class="row" id="moreCourses">
                <div class="col-12">
                    <h3>Aprenda mais blablabla</h3>
                    <div class="thumbnails row">
                        <div class="col-6">
                            <div class="thumbnail">
                                <img src="http://placehold.it/570x321" alt="web hosting 101">
                                <div class="label label-success price"><span class="glyphicon glyphicon-tag">R$39,90</span></div>
                                <div class="caption">
                                    <h3>Web Hosting 101</h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid animi beatae facere illo minima molestiae placeat sapiente, sit veniam voluptates! Et fuga ipsa maxime natus odio repellat repellendus tenetur ullam.</p>

                                    <p><a href="#" class="btn btn-primary btn-small" target="_blank">Clique ai!</a> <a href="#" target="_blank" class="btn btn-small btn-link">Aqui também!</a></p>
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="thumbnail">
                                <img src="http://placehold.it/570x321" alt="html 5">
                                <div class="label label-info price"><span class="glyphicon glyphicon-tag">R$60,90</span></div>
                                <div class="caption">
                                    <h3>HTML5</h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid animi beatae facere illo minima molestiae placeat sapiente, sit veniam voluptates! Et fuga ipsa maxime natus odio repellat repellendus tenetur ullam.</p>
                                    <p><a href="#" class="btn btn-primary btn-small" target="_blank">Clique ai!</a> <a href="#" target="_blank" class="btn btn-small btn-link">Aqui também!</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>


		</div>

		<footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <h6>Copyright &copy; 2016 {Cassiano }</h6>

                    </div>

                    <div class="col-sm-4">
                        <h6>Sobre nós</h6>
                        <p>Essa página está em desenvolvimento para testes de HTML 5 e CSS. Nosso objetivo é colocar em prática
                        os conhecimentos trabalhos nos cursos.  Delectus facilis illo laborum molestiae nam nulla, numquam ratione sit ut vitae. Est excepturi facere incidunt iste natus nobis possimus quidem velit.</p>
                    </div>

                    <div class="col-sm-2">
                        <h6>Menu</h6>
                        <ul class="unstyled">
                            <li><a href="">Home</a></li>
                            <li><a href="">Quem somos?</a></li>
                            <li><a href="">Contato</a></li>
                            <li><a href="">Login</a></li>
                        </ul>
                    </div>

                    <div class="col-sm-2">
                        <h6>Siga-nos</h6>
                        <ul class="unstyled">
                            <li><a href="">Facebook</a></li>
                            <li><a href="">Twitter</a></li>
                            <li><a href="">YouTube</a></li>
                            <li><a href="">Google Plus</a></li>
                        </ul>
                    </div>

                    <div class="col-sm-2">
                        <h6>Codificado com <span class="glyphicon glyphicon-music"></span> por Cassiano</h6>
                    </div>
                </div>
            </div>

		</footer>






	

	

	<!-- All Javascript at the bottom of the page for faster page loading -->
		
	<!-- First try for the online version of jQuery-->
	<script src="http://code.jquery.com/jquery.js"></script>
	
	<!-- If no online access, fallback to our hardcoded version of jQuery -->
	<script>window.jQuery || document.write('<script src="includes/js/jquery-1.8.2.min.js"><\/script>')</script>
	
	<!-- Bootstrap JS -->
	<script src="bootstrap/js/bootstrap.min.js"></script>
	
	<!-- Custom JS -->
	<script src="includes/js/script.js"></script>
	
	</body>
</html>

