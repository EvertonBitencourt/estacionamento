/*

My Custom JS
============

Author:  Brad Hussey
Updated: August 2013
Notes:	 Hand coded for Udemy.com

*/

/* Codigo da caixa de alerta */

$(function() {  //funções diversas

    // para abrir a caixa de alerta ao clicar o botão

    $('#alertaAqui').click(function(e){ // seleciona o botão e informa que "ao clicar" (.click()) vai haver uma função com o atributo e (que retorna para a classe)

        e.preventDefault(); // pede para o botão com o id alertaAqui não aja como o padrão. Ele é um link (a) e não deve abrir página qualquer.

        $('#successAlert').slideDown(); // então executa a ação no alerta com o id successAlert, fazendo que ele deslize para baixo (slideDown()).

    });

    //função para popover

    $('a.pop').click(function(e){
        e.preventDefault();
    });

    $('a.pop').popover();

    $('[rel="tooltip"]').tooltip();
})